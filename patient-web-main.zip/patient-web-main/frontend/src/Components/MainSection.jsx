// import React from "react";
// import RegistrationForm from "./RegistrationForm";
// import RightSideContent from "./RightSideContent";
import Login from "./Login";

const MainSection = () => {
  return (
    <section className=" ">
      <div className="form-box">
        {/* <RegistrationForm /> */}
        <Login/>
      </div>

    </section>
  );
};

export default MainSection;
